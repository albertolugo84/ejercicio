<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Exergy</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: top;

            }

            .opciones {
              color: #009fe5;
              padding: 0 25px;
              font-size: 14px;
              font-weight: 600;
              text-transform: uppercase;
              text-decoration: none;
              text-decoration-line: none;

            }
        </style>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
        <script src="https://code.highcharts.com/highcharts.js"></script>
        <script src="https://code.highcharts.com/modules/exporting.js"></script>

    </head>
    <body>

        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}" class="opciones">Inicio</a>

                    @endauth
                </div>
            @endif

            <div class="">

                     <img src="{{ asset('images/logo.png') }}"/><br/><br/>
                     <a href="{{ route('login') }}" class="opciones">Ingresa</a>
                     <a href="{{ route('register') }}" class="opciones">Crea una cuenta</a>




                <!--<div id="containers" style="min-width: 310px; height: 600px; margin: auto;">-->
                  <div id="containersr">
                  <script type="text/javascript">

                      $(function() {
                          $('#containers').highcharts( {"chart":{"type":"line"},"title":{"text":"Yearly sales"},"credits":{"enabled":false},"xAxis":{"categories":["2006","2007","2008","2009","2010","2011","2012","2013","2014","2015"]},"tooltip":{"valueSuffix":"$"},"series":[{"name":"Aidarex Pharmaceuticals LLC","data":[32587,30145,22015,18547,17895,25478,22145,24785,17842,21475]},{"name":"Antigen Laboratories, Inc.","data":[21487,22541,20158,19852,23014,20147,21475,18999,22365,24587]},{"name":"Aplicare, Inc.","data":[20005,22036,28741,30258,22584,19999,28746,31500,30099,20658]},{"name":"Apotheca Company","data":[19987,20136,30215,16854,20135,20598,20874,12896,19526,19874]},{"name":"Nelco Laboratories, Inc.","data":[20058,19874,22003,25008,20547,20158,19887,14875,12598,19854]},{"name":"Rimmel Inc.","data":[20589,12589,30202,19852,11205,30058,28563,19874,28542,17456]},{"name":"Sandoz Inc","data":[30540,25442,31852,31583,28121,25084,33376,26740,30290,29142]},{"name":"State of Florida DOH Central Pharmacy","data":[15258,18548,20107,29655,19697,26594,14518,20843,29527,27987]},{"name":"Uriel Pharmacy Inc.","data":[17349,17958,19607,26435,32397,28884,25818,32943,32317,14235]},{"name":"X-GEN Pharmaceuticals, Inc.","data":[23658,19548,20987,29855,10037,20024,20158,31543,19827,29637]}],"yAxis":{"title":{"text":"Sales ( $ )"}}})

                  //$('#container').highcharts( <?php //echo json_encode('$chartArray') ?>)
                        });

                </script>
                </div>
            </div>
        </div>
    </body>
</html>
